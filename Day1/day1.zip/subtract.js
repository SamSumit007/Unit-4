module.exports = function () {
    var a = 3;
    var b= 2;
    var subtract =0;
    subtract = a-b;
    console.log('subtract:', subtract)
  return 'subtract'
}
 