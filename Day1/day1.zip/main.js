const Add = require("./add");
const Subtract = require("./subtract");
const Multiply = require("./multiply");
const Devide = require("./devide");

console.log( Add());
console.log( Subtract());
console.log( Multiply());
console.log( Devide());
