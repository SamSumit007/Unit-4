module.exports = function () {
    var a = 8;
    var b= 2;
    var devide =0;
    devide = a/b;
    console.log('devide:', devide)
  return 'devide'
}
 