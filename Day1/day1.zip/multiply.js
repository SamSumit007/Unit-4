module.exports = function () {
    var a = 3;
    var b= 2;
    var product =0;
    product = a*b;
    console.log('product:', product)
  return 'product'
}
 