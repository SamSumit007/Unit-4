module.exports = function () {
    var a = 3;
    var b= 2;
    var sum =0;
    sum = a+b;
    console.log('sum:', sum)
  return 'sum'
}
 